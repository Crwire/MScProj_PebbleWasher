#include <pebble.h>
#include "Survey.h"

static Window *survey_window;
static AppTimer *timer;
static TextLayer *notify_layer;

static void timer_handler(){
	window_stack_pop(true);
}
static void display_survey(){
	window_stack_push(survey_window, true);
	
	text_layer_set_text(notify_layer, "Returning in 3s...");
	timer = app_timer_register(3000, (AppTimerCallback) timer_handler, NULL);
}

static void window_load(Window *window) {
  Layer *survey_window_layer = window_get_root_layer(survey_window);
  GRect bounds = layer_get_bounds(survey_window_layer);
  
  //Notify layer
  notify_layer = text_layer_create((GRect) { .origin = { 5, 5 }, .size = { bounds.size.w, 40 } });
  text_layer_set_text(notify_layer, "debug");
  layer_add_child(survey_window_layer, text_layer_get_layer(notify_layer));
  text_layer_set_font(notify_layer, fonts_get_system_font("RESOURCE_ID_GOTHIC_24"));
}

static void window_unload(Window *window) { //Cleanup resources
  text_layer_destroy(notify_layer);
}

static void survey_init(void) {
  survey_window = window_create();
  //window_set_click_config_provider(survey_window, click_config_provider);
  window_set_window_handlers(survey_window, (WindowHandlers) {
    .load = window_load,
    .unload = window_unload,
  });
  
  window_stack_push(survey_window, true);
}

static void survey_deinit(void) {
  window_destroy(survey_window);
}