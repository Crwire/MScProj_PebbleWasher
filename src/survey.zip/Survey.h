#pragma once

void display_survey(void);
void survey_init(void);
void survey_deinit(void);